"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recalculateInvoicePaid = recalculateInvoicePaid;
exports.listInvoices = listInvoices;
exports.getInvoiceById = getInvoiceById;
exports.listUnpaidInvoicesByPartner = listUnpaidInvoicesByPartner;
exports.createInvoice = createInvoice;
exports.updateInvoice = updateInvoice;
exports.deleteInvoice = deleteInvoice;
exports.listPayments = listPayments;
exports.getPaymentById = getPaymentById;
exports.createPayment = createPayment;
exports.updatePayment = updatePayment;
exports.deletePayment = deletePayment;
const database_1 = require("../db/database");
function computeInvoiceStatus(total, ongkir, paid) {
    const grandTagihan = Number(total || 0) + Number(ongkir || 0);
    if (paid <= 0)
        return 'Belum Lunas';
    if (paid >= grandTagihan - 0.01)
        return 'Lunas';
    return 'Cicil';
}
function computeFullyPaid(total, ongkir, paid) {
    const grandTagihan = Number(total || 0) + Number(ongkir || 0);
    if (grandTagihan > 0 && paid >= grandTagihan - 0.01)
        return 1;
    return null;
}
function recalculateInvoicePaid(invoiceId) {
    const inv = (0, database_1.queryOne)('SELECT total, ongkir FROM invoices WHERE id = ?', [invoiceId]);
    if (!inv)
        return;
    const paidRow = (0, database_1.queryOne)('SELECT COALESCE(SUM(subtotal), 0) AS sum_paid FROM payment_details WHERE invoice_id = ?', [invoiceId]);
    const paid = paidRow ? Number(paidRow.sum_paid || 0) : 0;
    const status = computeInvoiceStatus(inv.total, inv.ongkir, paid);
    const fullyPaid = computeFullyPaid(inv.total, inv.ongkir, paid);
    (0, database_1.execute)('UPDATE invoices SET paid = ?, status = ?, fully_paid = ? WHERE id = ?', [paid, status, fullyPaid, invoiceId], false);
}
// ==================== INVOICES ====================
function listInvoices(type) {
    const where = type ? 'WHERE i.type = ?' : '';
    const params = type ? [type] : [];
    return (0, database_1.queryAll)(`SELECT i.*,
            c.nama AS customer_nama,
            s.nama AS supplier_nama
     FROM invoices i
     LEFT JOIN customer c ON i.cust_id = c.id
     LEFT JOIN supplier s ON i.supp_id = s.id
     ${where}
     ORDER BY i.tgl DESC, i.id DESC`, params);
}
function getInvoiceById(id) {
    const inv = (0, database_1.queryOne)(`SELECT i.*,
            c.nama AS customer_nama,
            s.nama AS supplier_nama
     FROM invoices i
     LEFT JOIN customer c ON i.cust_id = c.id
     LEFT JOIN supplier s ON i.supp_id = s.id
     WHERE i.id = ?`, [id]);
    if (!inv)
        return null;
    inv.details = (0, database_1.queryAll)(`SELECT idet.*,
            b.kode AS barang_kode,
            b.nama AS barang_nama,
            b.part_number
     FROM invoice_details idet
     LEFT JOIN barang b ON idet.barang_id = b.id
     WHERE idet.invoice_id = ?
     ORDER BY idet.id ASC`, [id]);
    return inv;
}
function listUnpaidInvoicesByPartner(type, partnerId) {
    const col = type === 'out' ? 'cust_id' : 'supp_id';
    return (0, database_1.queryAll)(`SELECT i.*,
            c.nama AS customer_nama,
            s.nama AS supplier_nama
     FROM invoices i
     LEFT JOIN customer c ON i.cust_id = c.id
     LEFT JOIN supplier s ON i.supp_id = s.id
     WHERE i.type = ? AND i.${col} = ? AND i.fully_paid IS NULL
     ORDER BY i.tgl ASC, i.id ASC`, [type, partnerId]);
}
function createInvoice(data) {
    let newId = 0;
    (0, database_1.runTransaction)(() => {
        const details = data.details || [];
        const dpp = details.reduce((sum, item) => sum + Number(item.qty || 0) * Number(item.price || 0), 0);
        const diskon = Number(data.diskon || 0);
        const ppn = Number(data.ppn || 0);
        const ongkir = Number(data.ongkir || 0);
        const ppnNominal = Math.max(0, dpp - diskon) * (ppn / 100);
        const total = Math.max(0, dpp - diskon) + ppnNominal;
        const paid = Number(data.paid || 0);
        const status = computeInvoiceStatus(total, ongkir, paid);
        const fullyPaid = computeFullyPaid(total, ongkir, paid);
        const res = (0, database_1.execute)(`INSERT INTO invoices (
         no, tgl, type, order_no, delivery_note_no,
         dpp, ppn, ppn_nominal, cust_id, supp_id,
         diskon, ongkir, total, paid, fully_paid, status
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
            data.no,
            data.tgl,
            data.type,
            data.order_no || '',
            data.delivery_note_no || '',
            dpp,
            ppn,
            ppnNominal,
            data.type === 'out' ? data.cust_id ?? null : null,
            data.type === 'in' ? data.supp_id ?? null : null,
            diskon,
            ongkir,
            total,
            paid,
            fullyPaid,
            status,
        ], false);
        newId = res.lastInsertRowid;
        for (const item of details) {
            const qty = Number(item.qty || 0);
            const price = Number(item.price || 0);
            const subtotal = qty * price;
            (0, database_1.execute)(`INSERT INTO invoice_details (invoice_id, barang_id, qty, satuan, price, subtotal)
         VALUES (?, ?, ?, ?, ?, ?)`, [newId, item.barang_id, qty, item.satuan || 'PCS', price, subtotal], false);
        }
    });
    return getInvoiceById(newId);
}
function updateInvoice(id, data) {
    (0, database_1.runTransaction)(() => {
        const existing = (0, database_1.queryOne)('SELECT paid FROM invoices WHERE id = ?', [id]);
        const paidFromPaymentsRow = (0, database_1.queryOne)('SELECT COALESCE(SUM(subtotal), 0) AS sum_paid FROM payment_details WHERE invoice_id = ?', [id]);
        const paidFromPayments = paidFromPaymentsRow ? Number(paidFromPaymentsRow.sum_paid || 0) : 0;
        const details = data.details || [];
        const dpp = details.reduce((sum, item) => sum + Number(item.qty || 0) * Number(item.price || 0), 0);
        const diskon = Number(data.diskon || 0);
        const ppn = Number(data.ppn || 0);
        const ongkir = Number(data.ongkir || 0);
        const ppnNominal = Math.max(0, dpp - diskon) * (ppn / 100);
        const total = Math.max(0, dpp - diskon) + ppnNominal;
        const grandTagihan = total + ongkir;
        let paid = existing ? Number(existing.paid || 0) : 0;
        if (data.fully_paid === 1 || data.status === 'Lunas') {
            paid = Math.max(paidFromPayments, grandTagihan);
        }
        else if (data.fully_paid === null) {
            paid = paidFromPayments;
        }
        const status = computeInvoiceStatus(total, ongkir, paid);
        const fullyPaid = computeFullyPaid(total, ongkir, paid);
        (0, database_1.execute)(`UPDATE invoices
       SET no = ?, tgl = ?, type = ?, order_no = ?, delivery_note_no = ?,
           dpp = ?, ppn = ?, ppn_nominal = ?, cust_id = ?, supp_id = ?,
           diskon = ?, ongkir = ?, total = ?, paid = ?, fully_paid = ?, status = ?
       WHERE id = ?`, [
            data.no,
            data.tgl,
            data.type,
            data.order_no || '',
            data.delivery_note_no || '',
            dpp,
            ppn,
            ppnNominal,
            data.type === 'out' ? data.cust_id ?? null : null,
            data.type === 'in' ? data.supp_id ?? null : null,
            diskon,
            ongkir,
            total,
            paid,
            fullyPaid,
            status,
            id,
        ], false);
        (0, database_1.execute)('DELETE FROM invoice_details WHERE invoice_id = ?', [id], false);
        for (const item of details) {
            const qty = Number(item.qty || 0);
            const price = Number(item.price || 0);
            const subtotal = qty * price;
            (0, database_1.execute)(`INSERT INTO invoice_details (invoice_id, barang_id, qty, satuan, price, subtotal)
         VALUES (?, ?, ?, ?, ?, ?)`, [id, item.barang_id, qty, item.satuan || 'PCS', price, subtotal], false);
        }
    });
    return getInvoiceById(id);
}
function deleteInvoice(id) {
    (0, database_1.runTransaction)(() => {
        (0, database_1.execute)('DELETE FROM payment_details WHERE invoice_id = ?', [id], false);
        (0, database_1.execute)('DELETE FROM invoice_details WHERE invoice_id = ?', [id], false);
        (0, database_1.execute)('DELETE FROM invoices WHERE id = ?', [id], false);
    });
}
// ==================== PAYMENTS (PELUNASAN HUTANG / PIUTANG) ====================
function listPayments(type) {
    const where = type ? 'WHERE p.type = ?' : '';
    const params = type ? [type] : [];
    return (0, database_1.queryAll)(`SELECT p.*,
            c.nama AS customer_nama,
            s.nama AS supplier_nama
     FROM payments p
     LEFT JOIN customer c ON p.cust_id = c.id
     LEFT JOIN supplier s ON p.supp_id = s.id
     ${where}
     ORDER BY p.tgl DESC, p.id DESC`, params);
}
function getPaymentById(id) {
    const pay = (0, database_1.queryOne)(`SELECT p.*,
            c.nama AS customer_nama,
            s.nama AS supplier_nama
     FROM payments p
     LEFT JOIN customer c ON p.cust_id = c.id
     LEFT JOIN supplier s ON p.supp_id = s.id
     WHERE p.id = ?`, [id]);
    if (!pay)
        return null;
    pay.details = (0, database_1.queryAll)(`SELECT pd.*,
            i.no AS invoice_no,
            i.tgl AS invoice_tgl,
            (i.total + i.ongkir) AS invoice_total_tagihan,
            ((i.total + i.ongkir) - i.paid) AS invoice_sisa
     FROM payment_details pd
     LEFT JOIN invoices i ON pd.invoice_id = i.id
     WHERE pd.payment_id = ?
     ORDER BY pd.id ASC`, [id]);
    return pay;
}
function createPayment(data) {
    let newId = 0;
    (0, database_1.runTransaction)(() => {
        const details = (data.details || []).filter((d) => Number(d.subtotal || 0) > 0);
        const totalAllocated = details.reduce((s, d) => s + Number(d.subtotal || 0), 0);
        const deduction = Number(data.deduction || 0);
        const received = data.received !== undefined ? Number(data.received) : Math.max(0, totalAllocated - deduction);
        const res = (0, database_1.execute)(`INSERT INTO payments (no, tgl, total, received, deduction, deduction_note, keterangan, type, cust_id, supp_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
            data.no,
            data.tgl,
            totalAllocated,
            received,
            deduction,
            data.deduction_note || '',
            data.keterangan || '',
            data.type,
            data.type === 'in' ? data.cust_id ?? null : null,
            data.type === 'out' ? data.supp_id ?? null : null,
        ], false);
        newId = res.lastInsertRowid;
        const affectedInvoiceIds = new Set();
        for (const item of details) {
            (0, database_1.execute)(`INSERT INTO payment_details (payment_id, invoice_id, subtotal) VALUES (?, ?, ?)`, [newId, item.invoice_id, Number(item.subtotal || 0)], false);
            affectedInvoiceIds.add(item.invoice_id);
        }
        for (const invId of affectedInvoiceIds) {
            recalculateInvoicePaid(invId);
        }
    });
    return getPaymentById(newId);
}
function updatePayment(id, data) {
    (0, database_1.runTransaction)(() => {
        const oldDetails = (0, database_1.queryAll)('SELECT invoice_id FROM payment_details WHERE payment_id = ?', [id]);
        const affectedInvoiceIds = new Set(oldDetails.map((d) => d.invoice_id));
        (0, database_1.execute)('DELETE FROM payment_details WHERE payment_id = ?', [id], false);
        const details = (data.details || []).filter((d) => Number(d.subtotal || 0) > 0);
        const totalAllocated = details.reduce((s, d) => s + Number(d.subtotal || 0), 0);
        const deduction = Number(data.deduction || 0);
        const received = data.received !== undefined ? Number(data.received) : Math.max(0, totalAllocated - deduction);
        (0, database_1.execute)(`UPDATE payments
       SET no = ?, tgl = ?, total = ?, received = ?, deduction = ?, deduction_note = ?, keterangan = ?, type = ?, cust_id = ?, supp_id = ?
       WHERE id = ?`, [
            data.no,
            data.tgl,
            totalAllocated,
            received,
            deduction,
            data.deduction_note || '',
            data.keterangan || '',
            data.type,
            data.type === 'in' ? data.cust_id ?? null : null,
            data.type === 'out' ? data.supp_id ?? null : null,
            id,
        ], false);
        for (const item of details) {
            (0, database_1.execute)(`INSERT INTO payment_details (payment_id, invoice_id, subtotal) VALUES (?, ?, ?)`, [id, item.invoice_id, Number(item.subtotal || 0)], false);
            affectedInvoiceIds.add(item.invoice_id);
        }
        for (const invId of affectedInvoiceIds) {
            recalculateInvoicePaid(invId);
        }
    });
    return getPaymentById(id);
}
function deletePayment(id) {
    (0, database_1.runTransaction)(() => {
        const oldDetails = (0, database_1.queryAll)('SELECT invoice_id FROM payment_details WHERE payment_id = ?', [id]);
        const affectedInvoiceIds = new Set(oldDetails.map((d) => d.invoice_id));
        (0, database_1.execute)('DELETE FROM payment_details WHERE payment_id = ?', [id], false);
        (0, database_1.execute)('DELETE FROM payments WHERE id = ?', [id], false);
        for (const invId of affectedInvoiceIds) {
            recalculateInvoicePaid(invId);
        }
    });
}
