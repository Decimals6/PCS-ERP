"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.listOrders = listOrders;
exports.getOrderById = getOrderById;
exports.getOrderByNo = getOrderByNo;
exports.createOrder = createOrder;
exports.updateOrder = updateOrder;
exports.deleteOrder = deleteOrder;
exports.listDeliveryNotes = listDeliveryNotes;
exports.getDeliveryNoteById = getDeliveryNoteById;
exports.getDeliveryNoteForInvoice = getDeliveryNoteForInvoice;
exports.createDeliveryNote = createDeliveryNote;
exports.updateDeliveryNote = updateDeliveryNote;
exports.deleteDeliveryNote = deleteDeliveryNote;
exports.listMutasiBarang = listMutasiBarang;
exports.createManualMutasi = createManualMutasi;
exports.updateManualMutasi = updateManualMutasi;
exports.deleteManualMutasi = deleteManualMutasi;
exports.listSamples = listSamples;
exports.getSampleById = getSampleById;
exports.createSample = createSample;
exports.updateSample = updateSample;
exports.deleteSample = deleteSample;
exports.rebuildMutasiAndStockFromDocuments = rebuildMutasiAndStockFromDocuments;
exports.buildTransferPayload = buildTransferPayload;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const electron_1 = require("electron");
const database_1 = require("../db/database");
const pdfBackupService_1 = require("./pdfBackupService");
// ==================== ORDERS (PO / SO) ====================
function listOrders(type) {
    const where = type ? 'WHERE o.type = ?' : '';
    const params = type ? [type] : [];
    return (0, database_1.queryAll)(`SELECT o.*,
            c.nama AS customer_nama,
            s.nama AS supplier_nama
     FROM orders o
     LEFT JOIN customer c ON o.cust_id = c.id
     LEFT JOIN supplier s ON o.supp_id = s.id
     ${where}
     ORDER BY o.tgl DESC, o.id DESC`, params);
}
function getOrderById(id) {
    const order = (0, database_1.queryOne)(`SELECT o.*,
            c.nama AS customer_nama,
            s.nama AS supplier_nama
     FROM orders o
     LEFT JOIN customer c ON o.cust_id = c.id
     LEFT JOIN supplier s ON o.supp_id = s.id
     WHERE o.id = ?`, [id]);
    if (!order)
        return null;
    order.details = (0, database_1.queryAll)(`SELECT od.*,
            b.kode AS barang_kode,
            b.nama AS barang_nama,
            b.part_number,
            b.keterangan AS barang_keterangan
     FROM order_details od
     LEFT JOIN barang b ON od.barang_id = b.id
     WHERE od.order_id = ?
     ORDER BY od.id ASC`, [id]);
    return order;
}
function getOrderByNo(no) {
    const row = (0, database_1.queryOne)('SELECT id FROM orders WHERE no = ?', [no]);
    return row ? getOrderById(row.id) : null;
}
function createOrder(data) {
    let newId = 0;
    (0, database_1.runTransaction)(() => {
        const details = data.details || [];
        const dpp = details.reduce((sum, item) => sum + Number(item.qty || 0) * Number(item.price || 0), 0);
        const diskon = Number(data.diskon || 0);
        const ppn = Number(data.ppn || 0);
        const ongkir = Number(data.ongkir || 0);
        const ppnNominal = Math.max(0, dpp - diskon) * (ppn / 100);
        const total = Math.max(0, dpp - diskon) + ppnNominal;
        const res = (0, database_1.execute)(`INSERT INTO orders (tgl, no, type, cust_id, supp_id, dpp, ppn, diskon, ongkir, total, deldate, po_subject)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
            data.tgl,
            data.no,
            data.type,
            data.type === 'out' ? data.cust_id ?? null : null,
            data.type === 'in' ? data.supp_id ?? null : null,
            dpp,
            ppn,
            diskon,
            ongkir,
            total,
            data.type === 'in' ? data.deldate || '' : '',
            data.type === 'in' ? data.po_subject || '' : '',
        ], false);
        newId = res.lastInsertRowid;
        for (const item of details) {
            const qty = Number(item.qty || 0);
            const price = Number(item.price || 0);
            const subtotal = qty * price;
            (0, database_1.execute)(`INSERT INTO order_details (order_id, barang_id, qty, qty_sent, price, satuan, subtotal)
         VALUES (?, ?, ?, ?, ?, ?, ?)`, [newId, item.barang_id, qty, Number(item.qty_sent || 0), price, item.satuan || 'PCS', subtotal], false);
        }
    });
    return getOrderById(newId);
}
function updateOrder(id, data) {
    (0, database_1.runTransaction)(() => {
        const existingDetails = (0, database_1.queryAll)('SELECT * FROM order_details WHERE order_id = ?', [id]);
        const sentById = new Map();
        for (const ed of existingDetails) {
            if (ed.id)
                sentById.set(ed.id, Number(ed.qty_sent || 0));
        }
        const details = data.details || [];
        const dpp = details.reduce((sum, item) => sum + Number(item.qty || 0) * Number(item.price || 0), 0);
        const diskon = Number(data.diskon || 0);
        const ppn = Number(data.ppn || 0);
        const ongkir = Number(data.ongkir || 0);
        const ppnNominal = Math.max(0, dpp - diskon) * (ppn / 100);
        const total = Math.max(0, dpp - diskon) + ppnNominal;
        (0, database_1.execute)(`UPDATE orders
       SET tgl = ?, no = ?, type = ?, cust_id = ?, supp_id = ?, dpp = ?, ppn = ?, diskon = ?, ongkir = ?, total = ?, deldate = ?, po_subject = ?
       WHERE id = ?`, [
            data.tgl,
            data.no,
            data.type,
            data.type === 'out' ? data.cust_id ?? null : null,
            data.type === 'in' ? data.supp_id ?? null : null,
            dpp,
            ppn,
            diskon,
            ongkir,
            total,
            data.type === 'in' ? data.deldate || '' : '',
            data.type === 'in' ? data.po_subject || '' : '',
            id,
        ], false);
        (0, database_1.execute)('DELETE FROM order_details WHERE order_id = ?', [id], false);
        for (const item of details) {
            const qty = Number(item.qty || 0);
            const price = Number(item.price || 0);
            const subtotal = qty * price;
            const preservedSent = item.id && sentById.has(item.id) ? sentById.get(item.id) : Number(item.qty_sent || 0);
            (0, database_1.execute)(`INSERT INTO order_details (order_id, barang_id, qty, qty_sent, price, satuan, subtotal)
         VALUES (?, ?, ?, ?, ?, ?, ?)`, [id, item.barang_id, qty, preservedSent, price, item.satuan || 'PCS', subtotal], false);
        }
    });
    return getOrderById(id);
}
function deleteOrder(id) {
    (0, database_1.runTransaction)(() => {
        (0, database_1.execute)('DELETE FROM order_details WHERE order_id = ?', [id], false);
        (0, database_1.execute)('DELETE FROM orders WHERE id = ?', [id], false);
    });
}
// ==================== DELIVERY NOTES (SURAT JALAN) ====================
function listDeliveryNotes(type) {
    const where = type ? 'WHERE dn.type = ?' : '';
    const params = type ? [type] : [];
    return (0, database_1.queryAll)(`SELECT dn.* FROM delivery_notes dn ${where} ORDER BY dn.tgl DESC, dn.id DESC`, params);
}
function getDeliveryNoteById(id) {
    const dn = (0, database_1.queryOne)('SELECT * FROM delivery_notes WHERE id = ?', [id]);
    if (!dn)
        return null;
    dn.details = (0, database_1.queryAll)(`SELECT dnd.*,
            b.kode AS barang_kode,
            b.nama AS barang_nama,
            b.satuan AS barang_satuan,
            b.part_number
     FROM delivery_note_details dnd
     LEFT JOIN barang b ON dnd.barang_id = b.id
     WHERE dnd.delivery_note_id = ?
     ORDER BY dnd.id ASC`, [id]);
    return dn;
}
function getDeliveryNoteForInvoice(no) {
    const trimmedNo = String(no || '').trim();
    if (!trimmedNo)
        return null;
    const row = (0, database_1.queryOne)('SELECT id FROM delivery_notes WHERE no = ?', [trimmedNo]);
    if (!row)
        return null;
    const dn = getDeliveryNoteById(row.id);
    if (!dn)
        return null;
    const order = dn.order_no ? getOrderByNo(dn.order_no) : null;
    const orderDetails = order?.details || [];
    const items = (dn.details || []).map((d) => {
        const matchedOrderDetail = (d.order_detail_id
            ? orderDetails.find((od) => od.id === d.order_detail_id)
            : undefined) ||
            orderDetails.find((od) => Number(od.barang_id) === Number(d.barang_id));
        return {
            barang_id: d.barang_id,
            barang_kode: d.barang_kode,
            barang_nama: d.barang_nama,
            part_number: d.part_number,
            qty: Number(d.qty_sent || 0),
            satuan: matchedOrderDetail?.satuan || d.barang_satuan || 'PCS',
            price: matchedOrderDetail ? Number(matchedOrderDetail.price || 0) : 0,
        };
    });
    return {
        delivery_note: dn,
        order,
        items,
    };
}
/**
 * Menyusun ulang saldo berjalan (stok_sebelum, stok_sesudah) secara kronologis
 * (tgl ASC, id ASC) untuk satu barang dan menyinkronkan barang.stock akhir.
 * Baseline awal diturunkan dari stok sebelum mutasi pertama yang tercatat,
 * atau dari (barang.stock - netDeltaSaatIni) bila mutasi pertama disisipkan sebelum riwayat lama.
 */
function recalculateBarangLedger(barangId, explicitInitialStock) {
    const barang = (0, database_1.queryOne)('SELECT stock FROM barang WHERE id = ?', [barangId]);
    if (!barang)
        return;
    const rows = (0, database_1.queryAll)(`SELECT id, type, qty, stok_sebelum, stok_sesudah
     FROM mutasi_barang
     WHERE barang_id = ?
     ORDER BY tgl ASC, id ASC`, [barangId]);
    let runningStock = explicitInitialStock !== undefined
        ? Number(explicitInitialStock)
        : rows.length > 0
            ? Number(rows[0].stok_sebelum || 0)
            : Number(barang.stock || 0);
    for (const row of rows) {
        const qty = Number(row.qty || 0);
        const stokSebelum = runningStock;
        const stokSesudah = row.type === 'in' ? stokSebelum + qty : stokSebelum - qty;
        if (Number(row.stok_sebelum) !== stokSebelum || Number(row.stok_sesudah) !== stokSesudah) {
            (0, database_1.execute)('UPDATE mutasi_barang SET stok_sebelum = ?, stok_sesudah = ? WHERE id = ?', [stokSebelum, stokSesudah, row.id], false);
        }
        runningStock = stokSesudah;
    }
    if (Number(barang.stock) !== runningStock) {
        (0, database_1.execute)('UPDATE barang SET stock = ? WHERE id = ?', [runningStock, barangId], false);
    }
}
function getBarangInitialBaseline(barangId) {
    const barang = (0, database_1.queryOne)('SELECT stock FROM barang WHERE id = ?', [barangId]);
    const currentStock = barang ? Number(barang.stock || 0) : 0;
    const existingRows = (0, database_1.queryAll)('SELECT type, qty FROM mutasi_barang WHERE barang_id = ?', [barangId]);
    const netDelta = existingRows.reduce((acc, r) => acc + (r.type === 'in' ? Number(r.qty || 0) : -Number(r.qty || 0)), 0);
    return currentStock - netDelta;
}
function rollbackDeliveryEffects(dnId) {
    const existingDn = (0, database_1.queryOne)('SELECT * FROM delivery_notes WHERE id = ?', [dnId]);
    if (!existingDn)
        return;
    const existingDetails = (0, database_1.queryAll)('SELECT * FROM delivery_note_details WHERE delivery_note_id = ?', [dnId]);
    const affectedBarangIds = new Set();
    const baselines = new Map();
    for (const item of existingDetails) {
        const qtySent = Number(item.qty_sent || 0);
        if (!baselines.has(item.barang_id)) {
            baselines.set(item.barang_id, getBarangInitialBaseline(item.barang_id));
        }
        affectedBarangIds.add(item.barang_id);
        if (item.order_detail_id) {
            const od = (0, database_1.queryOne)('SELECT qty_sent FROM order_details WHERE id = ?', [
                item.order_detail_id,
            ]);
            if (od) {
                const restoredSent = Math.max(0, Number(od.qty_sent || 0) - qtySent);
                (0, database_1.execute)('UPDATE order_details SET qty_sent = ? WHERE id = ?', [restoredSent, item.order_detail_id], false);
            }
        }
    }
    (0, database_1.execute)('DELETE FROM mutasi_barang WHERE delivery_note_id = ?', [dnId], false);
    (0, database_1.execute)('DELETE FROM delivery_note_details WHERE delivery_note_id = ?', [dnId], false);
    for (const bId of affectedBarangIds) {
        recalculateBarangLedger(bId, baselines.get(bId));
    }
}
function applyDeliveryEffects(dnId, data) {
    const details = data.details || [];
    const affectedBarangIds = new Set();
    const baselines = new Map();
    for (const item of details) {
        const qtySent = Number(item.qty_sent || 0);
        if (qtySent <= 0)
            continue;
        if (!baselines.has(item.barang_id)) {
            baselines.set(item.barang_id, getBarangInitialBaseline(item.barang_id));
        }
        affectedBarangIds.add(item.barang_id);
        (0, database_1.execute)(`INSERT INTO delivery_note_details (delivery_note_id, order_detail_id, barang_id, qty_sent)
       VALUES (?, ?, ?, ?)`, [dnId, item.order_detail_id ?? null, item.barang_id, qtySent], false);
        const barang = (0, database_1.queryOne)('SELECT stock FROM barang WHERE id = ?', [item.barang_id]);
        const stokSebelum = barang ? Number(barang.stock || 0) : 0;
        const stokSesudah = data.type === 'in' ? stokSebelum + qtySent : stokSebelum - qtySent;
        (0, database_1.execute)(`INSERT INTO mutasi_barang (barang_id, type, qty, stok_sebelum, stok_sesudah, tgl, source, delivery_note_id, keterangan)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
            item.barang_id,
            data.type,
            qtySent,
            stokSebelum,
            stokSesudah,
            data.tgl,
            `SJ: ${data.no}`,
            dnId,
            data.keterangan || (data.type === 'in' ? 'Penerimaan Barang' : 'Pengiriman Barang'),
        ], false);
        if (item.order_detail_id) {
            const od = (0, database_1.queryOne)('SELECT qty_sent FROM order_details WHERE id = ?', [
                item.order_detail_id,
            ]);
            if (od) {
                const updatedSent = Number(od.qty_sent || 0) + qtySent;
                (0, database_1.execute)('UPDATE order_details SET qty_sent = ? WHERE id = ?', [updatedSent, item.order_detail_id], false);
            }
        }
    }
    for (const bId of affectedBarangIds) {
        recalculateBarangLedger(bId, baselines.get(bId));
    }
}
function createDeliveryNote(data) {
    let newId = 0;
    (0, database_1.runTransaction)(() => {
        const res = (0, database_1.execute)(`INSERT INTO delivery_notes (no, tgl, order_no, alamat_tujuan, keterangan, type)
       VALUES (?, ?, ?, ?, ?, ?)`, [data.no, data.tgl, data.order_no || '', data.alamat_tujuan || '', data.keterangan || '', data.type], false);
        newId = res.lastInsertRowid;
        applyDeliveryEffects(newId, data);
    });
    return getDeliveryNoteById(newId);
}
function updateDeliveryNote(id, data) {
    (0, database_1.runTransaction)(() => {
        rollbackDeliveryEffects(id);
        (0, database_1.execute)(`UPDATE delivery_notes
       SET no = ?, tgl = ?, order_no = ?, alamat_tujuan = ?, keterangan = ?, type = ?
       WHERE id = ?`, [data.no, data.tgl, data.order_no || '', data.alamat_tujuan || '', data.keterangan || '', data.type, id], false);
        applyDeliveryEffects(id, data);
    });
    return getDeliveryNoteById(id);
}
function deleteDeliveryNote(id) {
    (0, database_1.runTransaction)(() => {
        rollbackDeliveryEffects(id);
        (0, database_1.execute)('DELETE FROM delivery_notes WHERE id = ?', [id], false);
    });
}
function listMutasiBarang(barangId) {
    const where = barangId ? 'WHERE m.barang_id = ?' : '';
    const params = barangId ? [barangId] : [];
    return (0, database_1.queryAll)(`SELECT m.*,
            b.kode AS barang_kode,
            b.nama AS barang_nama,
            b.satuan AS barang_satuan
     FROM mutasi_barang m
     LEFT JOIN barang b ON m.barang_id = b.id
     ${where}
     ORDER BY m.tgl DESC, m.id DESC`, params);
}
function createManualMutasi(data) {
    let newId = 0;
    (0, database_1.runTransaction)(() => {
        const barangId = Number(data.barang_id);
        const qty = Number(data.qty || 0);
        if (!barangId || qty <= 0) {
            throw new Error('Barang dan jumlah mutasi (> 0) wajib diisi.');
        }
        const barang = (0, database_1.queryOne)('SELECT stock FROM barang WHERE id = ?', [barangId]);
        if (!barang) {
            throw new Error('Data barang tidak ditemukan.');
        }
        const initialBaseline = getBarangInitialBaseline(barangId);
        const stokSebelum = Number(barang.stock || 0);
        const stokSesudah = data.type === 'in' ? stokSebelum + qty : stokSebelum - qty;
        const sourceText = String(data.source || '').trim() || 'MANUAL';
        const res = (0, database_1.execute)(`INSERT INTO mutasi_barang (barang_id, type, qty, stok_sebelum, stok_sesudah, tgl, source, delivery_note_id, sample_id, keterangan)
       VALUES (?, ?, ?, ?, ?, ?, ?, NULL, NULL, ?)`, [barangId, data.type, qty, stokSebelum, stokSesudah, data.tgl, sourceText, data.keterangan || ''], false);
        newId = res.lastInsertRowid;
        recalculateBarangLedger(barangId, initialBaseline);
    });
    return (0, database_1.queryOne)(`SELECT m.*, b.kode AS barang_kode, b.nama AS barang_nama, b.satuan AS barang_satuan
     FROM mutasi_barang m LEFT JOIN barang b ON m.barang_id = b.id WHERE m.id = ?`, [newId]);
}
function updateManualMutasi(id, data) {
    (0, database_1.runTransaction)(() => {
        const existing = (0, database_1.queryOne)('SELECT * FROM mutasi_barang WHERE id = ?', [id]);
        if (!existing) {
            throw new Error('Data mutasi barang tidak ditemukan.');
        }
        if (existing.delivery_note_id || existing.sample_id) {
            throw new Error('Mutasi otomatis dari Surat Jalan / Sample hanya dapat diubah melalui dokumen asalnya.');
        }
        const newBarangId = Number(data.barang_id);
        const newQty = Number(data.qty || 0);
        if (!newBarangId || newQty <= 0) {
            throw new Error('Barang dan jumlah mutasi (> 0) wajib diisi.');
        }
        const targetBarang = (0, database_1.queryOne)('SELECT stock FROM barang WHERE id = ?', [newBarangId]);
        if (!targetBarang) {
            throw new Error('Data barang tujuan tidak ditemukan.');
        }
        const oldBarangId = Number(existing.barang_id);
        const oldBaseline = getBarangInitialBaseline(oldBarangId);
        const newBaseline = oldBarangId === newBarangId ? oldBaseline : getBarangInitialBaseline(newBarangId);
        const sourceText = String(data.source || '').trim() || 'MANUAL';
        (0, database_1.execute)(`UPDATE mutasi_barang
       SET barang_id = ?, type = ?, qty = ?, tgl = ?, source = ?, keterangan = ?
       WHERE id = ?`, [newBarangId, data.type, newQty, data.tgl, sourceText, data.keterangan || '', id], false);
        recalculateBarangLedger(oldBarangId, oldBaseline);
        if (newBarangId !== oldBarangId) {
            recalculateBarangLedger(newBarangId, newBaseline);
        }
    });
    return (0, database_1.queryOne)(`SELECT m.*, b.kode AS barang_kode, b.nama AS barang_nama, b.satuan AS barang_satuan
     FROM mutasi_barang m LEFT JOIN barang b ON m.barang_id = b.id WHERE m.id = ?`, [id]);
}
function deleteManualMutasi(id) {
    (0, database_1.runTransaction)(() => {
        const existing = (0, database_1.queryOne)('SELECT * FROM mutasi_barang WHERE id = ?', [id]);
        if (!existing)
            return;
        if (existing.delivery_note_id || existing.sample_id) {
            throw new Error('Mutasi otomatis dari Surat Jalan / Sample tidak dapat dihapus langsung dari sini.');
        }
        const barangId = Number(existing.barang_id);
        const baseline = getBarangInitialBaseline(barangId);
        (0, database_1.execute)('DELETE FROM mutasi_barang WHERE id = ?', [id], false);
        recalculateBarangLedger(barangId, baseline);
    });
}
// ==================== SAMPLES (TANDA TERIMA SAMPEL) ====================
function listSamples() {
    return (0, database_1.queryAll)(`SELECT sp.*,
            c.nama AS customer_nama,
            c.alamat AS customer_alamat
     FROM samples sp
     LEFT JOIN customer c ON sp.id_customer = c.id
     ORDER BY sp.tgl DESC, sp.id DESC`);
}
function getSampleById(id) {
    const sp = (0, database_1.queryOne)(`SELECT sp.*,
            c.nama AS customer_nama,
            c.alamat AS customer_alamat
     FROM samples sp
     LEFT JOIN customer c ON sp.id_customer = c.id
     WHERE sp.id = ?`, [id]);
    if (!sp)
        return null;
    sp.details = (0, database_1.queryAll)(`SELECT sb.*,
            b.kode AS barang_kode,
            b.nama AS barang_nama,
            b.satuan AS barang_satuan,
            b.part_number
     FROM sample_barangs sb
     LEFT JOIN barang b ON sb.id_barangs = b.id
     WHERE sb.id_sample = ?
     ORDER BY sb.id ASC`, [id]);
    return sp;
}
function rollbackSampleEffects(sampleId) {
    const existingDetails = (0, database_1.queryAll)('SELECT * FROM sample_barangs WHERE id_sample = ?', [sampleId]);
    const affectedBarangIds = new Set();
    const baselines = new Map();
    for (const item of existingDetails) {
        if (!baselines.has(item.id_barangs)) {
            baselines.set(item.id_barangs, getBarangInitialBaseline(item.id_barangs));
        }
        affectedBarangIds.add(item.id_barangs);
    }
    (0, database_1.execute)('DELETE FROM mutasi_barang WHERE sample_id = ?', [sampleId], false);
    (0, database_1.execute)('DELETE FROM sample_barangs WHERE id_sample = ?', [sampleId], false);
    for (const bId of affectedBarangIds) {
        recalculateBarangLedger(bId, baselines.get(bId));
    }
}
function applySampleEffects(sampleId, data) {
    const details = data.details || [];
    const affectedBarangIds = new Set();
    const baselines = new Map();
    for (const item of details) {
        const qty = Number(item.qty || 0);
        if (qty <= 0)
            continue;
        if (!baselines.has(item.id_barangs)) {
            baselines.set(item.id_barangs, getBarangInitialBaseline(item.id_barangs));
        }
        affectedBarangIds.add(item.id_barangs);
        const barang = (0, database_1.queryOne)('SELECT stock, satuan FROM barang WHERE id = ?', [
            item.id_barangs,
        ]);
        const satuanFinal = String(item.satuan || '').trim() || barang?.satuan || 'PCS';
        (0, database_1.execute)(`INSERT INTO sample_barangs (id_sample, id_barangs, qty, satuan)
       VALUES (?, ?, ?, ?)`, [sampleId, item.id_barangs, qty, satuanFinal], false);
        const stokSebelum = barang ? Number(barang.stock || 0) : 0;
        const stokSesudah = stokSebelum - qty;
        (0, database_1.execute)(`INSERT INTO mutasi_barang (barang_id, type, qty, stok_sebelum, stok_sesudah, tgl, source, sample_id, keterangan)
       VALUES (?, 'out', ?, ?, ?, ?, ?, ?, ?)`, [
            item.id_barangs,
            qty,
            stokSebelum,
            stokSesudah,
            data.tgl,
            `SP: ${data.no}`,
            sampleId,
            data.keterangan || 'Sample Barang untuk Customer',
        ], false);
    }
    for (const bId of affectedBarangIds) {
        recalculateBarangLedger(bId, baselines.get(bId));
    }
}
function createSample(data) {
    let newId = 0;
    (0, database_1.runTransaction)(() => {
        const res = (0, database_1.execute)(`INSERT INTO samples (no, tgl, id_customer, penerima_nama, keterangan)
       VALUES (?, ?, ?, ?, ?)`, [data.no, data.tgl, data.id_customer ?? null, data.penerima_nama || '', data.keterangan || ''], false);
        newId = res.lastInsertRowid;
        applySampleEffects(newId, data);
    });
    return getSampleById(newId);
}
function updateSample(id, data) {
    (0, database_1.runTransaction)(() => {
        rollbackSampleEffects(id);
        (0, database_1.execute)(`UPDATE samples
       SET no = ?, tgl = ?, id_customer = ?, penerima_nama = ?, keterangan = ?
       WHERE id = ?`, [data.no, data.tgl, data.id_customer ?? null, data.penerima_nama || '', data.keterangan || '', id], false);
        applySampleEffects(id, data);
    });
    return getSampleById(id);
}
function deleteSample(id) {
    (0, database_1.runTransaction)(() => {
        rollbackSampleEffects(id);
        (0, database_1.execute)('DELETE FROM samples WHERE id = ?', [id], false);
    });
}
// ==================== REBUILD STOK & MUTASI DARI DOKUMEN ====================
function rebuildMutasiAndStockFromDocuments(options) {
    const mode = options?.mode === 'from_date' ? 'from_date' : 'all';
    const fromDate = mode === 'from_date' ? String(options.fromDate || '').trim() : '';
    const keepManual = Boolean(options?.keepManualMutasi);
    if (mode === 'from_date' && !fromDate) {
        throw new Error('Tanggal awal (fromDate) wajib diisi untuk mode rebuild mulai tanggal tertentu.');
    }
    // 1. Auto-backup database sebelum melakukan perubahan apa pun
    (0, database_1.saveDatabase)();
    const activeDbPath = (0, database_1.getDbPath)();
    const backupDir = path_1.default.join(electron_1.app.getPath('userData'), 'backups');
    if (!fs_1.default.existsSync(backupDir)) {
        fs_1.default.mkdirSync(backupDir, { recursive: true });
    }
    const now = new Date();
    const stamp = [
        now.getFullYear(),
        String(now.getMonth() + 1).padStart(2, '0'),
        String(now.getDate()).padStart(2, '0'),
        '_',
        String(now.getHours()).padStart(2, '0'),
        String(now.getMinutes()).padStart(2, '0'),
        String(now.getSeconds()).padStart(2, '0'),
    ].join('');
    const backupPath = path_1.default.join(backupDir, `auto_backup_before_rebuild_${stamp}.db`);
    fs_1.default.copyFileSync(activeDbPath, backupPath);
    const customBackupPath = (0, pdfBackupService_1.copyBackupToCustomFolder)(backupPath);
    let rebuiltAutoCount = 0;
    let recalculatedManualCount = 0;
    let affectedBarangCount = 0;
    (0, database_1.runTransaction)(() => {
        const allBarang = (0, database_1.queryAll)('SELECT id, stock FROM barang');
        const baselines = new Map();
        // 2. Tentukan baseline saldo awal per barang sebelum titik rebuild
        for (const b of allBarang) {
            if (mode === 'all') {
                baselines.set(b.id, 0);
            }
            else {
                const lastBefore = (0, database_1.queryOne)(`SELECT stok_sesudah FROM mutasi_barang
           WHERE barang_id = ? AND tgl < ?
           ORDER BY tgl DESC, id DESC
           LIMIT 1`, [b.id, fromDate]);
                if (lastBefore) {
                    baselines.set(b.id, Number(lastBefore.stok_sesudah || 0));
                }
                else {
                    baselines.set(b.id, getBarangInitialBaseline(b.id));
                }
            }
        }
        // 3. Bersihkan mutasi lama sesuai scope & opsi keepManual
        if (mode === 'all') {
            if (keepManual) {
                (0, database_1.execute)('DELETE FROM mutasi_barang WHERE delivery_note_id IS NOT NULL OR sample_id IS NOT NULL', [], false);
            }
            else {
                (0, database_1.execute)('DELETE FROM mutasi_barang', [], false);
            }
        }
        else {
            if (keepManual) {
                (0, database_1.execute)('DELETE FROM mutasi_barang WHERE tgl >= ? AND (delivery_note_id IS NOT NULL OR sample_id IS NOT NULL)', [fromDate], false);
            }
            else {
                (0, database_1.execute)('DELETE FROM mutasi_barang WHERE tgl >= ?', [fromDate], false);
            }
        }
        const seeds = [];
        const dnWhere = mode === 'from_date' ? 'WHERE dn.tgl >= ?' : '';
        const dnParams = mode === 'from_date' ? [fromDate] : [];
        const dnItems = (0, database_1.queryAll)(`SELECT dnd.id AS detail_id,
              dn.id AS dn_id,
              dn.no,
              dn.tgl,
              dn.type,
              dn.keterangan,
              dnd.barang_id,
              dnd.qty_sent
       FROM delivery_note_details dnd
       INNER JOIN delivery_notes dn ON dnd.delivery_note_id = dn.id
       ${dnWhere}`, dnParams);
        for (const row of dnItems) {
            const qty = Number(row.qty_sent || 0);
            if (qty <= 0 || !row.barang_id)
                continue;
            seeds.push({
                barang_id: Number(row.barang_id),
                type: row.type === 'in' ? 'in' : 'out',
                qty,
                tgl: row.tgl,
                source: `SJ: ${row.no}`,
                delivery_note_id: Number(row.dn_id),
                sample_id: null,
                doc_id: Number(row.dn_id),
                detail_id: Number(row.detail_id),
                keterangan: row.keterangan || (row.type === 'in' ? 'Penerimaan Barang' : 'Pengiriman Barang'),
            });
        }
        const spWhere = mode === 'from_date' ? 'WHERE sp.tgl >= ?' : '';
        const spParams = mode === 'from_date' ? [fromDate] : [];
        const spItems = (0, database_1.queryAll)(`SELECT sb.id AS detail_id,
              sp.id AS sp_id,
              sp.no,
              sp.tgl,
              sp.keterangan,
              sb.id_barangs AS barang_id,
              sb.qty
       FROM sample_barangs sb
       INNER JOIN samples sp ON sb.id_sample = sp.id
       ${spWhere}`, spParams);
        for (const row of spItems) {
            const qty = Number(row.qty || 0);
            if (qty <= 0 || !row.barang_id)
                continue;
            seeds.push({
                barang_id: Number(row.barang_id),
                type: 'out',
                qty,
                tgl: row.tgl,
                source: `SP: ${row.no}`,
                delivery_note_id: null,
                sample_id: Number(row.sp_id),
                doc_id: Number(row.sp_id),
                detail_id: Number(row.detail_id),
                keterangan: row.keterangan || 'Sample Barang untuk Customer',
            });
        }
        // Urutkan kronologis: tgl ASC, lalu 'in' lebih dulu dari 'out', lalu doc_id & detail_id ASC
        seeds.sort((a, b) => {
            const dateCmp = String(a.tgl || '').localeCompare(String(b.tgl || ''));
            if (dateCmp !== 0)
                return dateCmp;
            if (a.type !== b.type)
                return a.type === 'in' ? -1 : 1;
            if (a.doc_id !== b.doc_id)
                return a.doc_id - b.doc_id;
            return a.detail_id - b.detail_id;
        });
        // 5. Insert ulang mutasi otomatis
        for (const s of seeds) {
            (0, database_1.execute)(`INSERT INTO mutasi_barang (barang_id, type, qty, stok_sebelum, stok_sesudah, tgl, source, delivery_note_id, sample_id, keterangan)
         VALUES (?, ?, ?, 0, 0, ?, ?, ?, ?, ?)`, [
                s.barang_id,
                s.type,
                s.qty,
                s.tgl,
                s.source,
                s.delivery_note_id,
                s.sample_id,
                s.keterangan,
            ], false);
            rebuiltAutoCount++;
        }
        // 6. Hitung ulang saldo berjalan seluruh barang (otomatis menyisipkan mutasi manual pada tanggalnya)
        for (const b of allBarang) {
            const baseline = baselines.get(b.id) ?? 0;
            recalculateBarangLedger(b.id, baseline);
            affectedBarangCount++;
        }
        if (keepManual) {
            const manualRes = (0, database_1.queryOne)(mode === 'from_date'
                ? 'SELECT COUNT(*) AS cnt FROM mutasi_barang WHERE tgl >= ? AND delivery_note_id IS NULL AND sample_id IS NULL'
                : 'SELECT COUNT(*) AS cnt FROM mutasi_barang WHERE delivery_note_id IS NULL AND sample_id IS NULL', mode === 'from_date' ? [fromDate] : []);
            recalculatedManualCount = manualRes ? Number(manualRes.cnt || 0) : 0;
        }
    });
    return {
        backupPath,
        customBackupPath,
        affectedBarangCount,
        rebuiltAutoCount,
        recalculatedManualCount,
    };
}
// ==================== TRANSFER DOKUMEN ANTARDIVISI (.JSON) ====================
function buildTransferPayload(docKind, id) {
    if (docKind === 'ORDER') {
        const order = getOrderById(id);
        if (!order)
            throw new Error('Dokumen Order tidak ditemukan.');
        const partner = order.type === 'out' && order.cust_id
            ? (0, database_1.queryOne)('SELECT * FROM customer WHERE id = ?', [order.cust_id])
            : order.type === 'in' && order.supp_id
                ? (0, database_1.queryOne)('SELECT * FROM supplier WHERE id = ?', [order.supp_id])
                : null;
        return {
            format_version: '1.0',
            exported_at: new Date().toISOString(),
            doc_kind: 'ORDER',
            header: {
                no: order.no,
                tgl: order.tgl,
                type: order.type,
                dpp: order.dpp,
                ppn: order.ppn,
                diskon: order.diskon,
                ongkir: order.ongkir,
                total: order.total,
            },
            partner,
            items: (order.details || []).map((d) => ({
                barang_kode: d.barang_kode || '',
                barang_nama: d.barang_nama || '',
                part_number: d.part_number || '',
                satuan: d.satuan,
                qty: d.qty,
                price: d.price,
                subtotal: d.subtotal,
            })),
        };
    }
    const dn = getDeliveryNoteById(id);
    if (!dn)
        throw new Error('Dokumen Surat Jalan tidak ditemukan.');
    return {
        format_version: '1.0',
        exported_at: new Date().toISOString(),
        doc_kind: 'DELIVERY_NOTE',
        header: {
            no: dn.no,
            tgl: dn.tgl,
            order_no: dn.order_no,
            alamat_tujuan: dn.alamat_tujuan,
            keterangan: dn.keterangan,
            type: dn.type,
        },
        partner: null,
        items: (dn.details || []).map((d) => ({
            barang_kode: d.barang_kode || '',
            barang_nama: d.barang_nama || '',
            part_number: d.part_number || '',
            satuan: d.barang_satuan || 'PCS',
            qty: d.qty_sent,
        })),
    };
}
