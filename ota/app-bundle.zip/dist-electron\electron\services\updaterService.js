"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCurrentAppVersion = getCurrentAppVersion;
exports.checkForOtaUpdate = checkForOtaUpdate;
exports.downloadAndApplyOtaUpdate = downloadAndApplyOtaUpdate;
const electron_1 = require("electron");
const crypto_1 = __importDefault(require("crypto"));
const fs_1 = __importDefault(require("fs"));
const os_1 = __importDefault(require("os"));
const path_1 = __importDefault(require("path"));
const child_process_1 = require("child_process");
const GITHUB_RAW_BASE = 'https://raw.githubusercontent.com/Decimals6/PCS-ERP/main/ota';
const MANIFEST_URL = `${GITHUB_RAW_BASE}/version.json`;
function compareSemver(a, b) {
    const pa = String(a || '')
        .replace(/^v/i, '')
        .split('.')
        .map((n) => parseInt(n, 10) || 0);
    const pb = String(b || '')
        .replace(/^v/i, '')
        .split('.')
        .map((n) => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
        const diff = (pa[i] || 0) - (pb[i] || 0);
        if (diff !== 0)
            return diff;
    }
    return 0;
}
function getCurrentAppVersion() {
    try {
        const pkgPath = path_1.default.join(electron_1.app.getAppPath(), 'package.json');
        if (fs_1.default.existsSync(pkgPath)) {
            const parsed = JSON.parse(fs_1.default.readFileSync(pkgPath, 'utf-8'));
            if (parsed.version)
                return String(parsed.version);
        }
    }
    catch {
        // fallback to app.getVersion()
    }
    return electron_1.app.getVersion();
}
async function checkForOtaUpdate() {
    const currentVersion = getCurrentAppVersion();
    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 8000);
        const res = await fetch(`${MANIFEST_URL}?t=${Date.now()}`, {
            cache: 'no-store',
            signal: controller.signal,
        });
        clearTimeout(timeout);
        if (!res.ok) {
            return {
                hasUpdate: false,
                currentVersion,
                latestVersion: currentVersion,
                error: res.status === 404
                    ? 'Manifest update belum dipublikasikan di repository GitHub.'
                    : `Server GitHub merespons HTTP ${res.status}`,
            };
        }
        const manifest = (await res.json());
        const latestVersion = String(manifest.version || currentVersion).trim();
        const isNewer = compareSemver(latestVersion, currentVersion) > 0;
        return {
            hasUpdate: isNewer,
            currentVersion,
            latestVersion,
            releaseDate: manifest.releaseDate,
            notes: manifest.notes,
            bundleUrl: manifest.bundleUrl,
            sha256: manifest.sha256,
        };
    }
    catch {
        return {
            hasUpdate: false,
            currentVersion,
            latestVersion: currentVersion,
            offline: true,
            error: 'Tidak dapat terhubung ke GitHub (Mode Offline / Koneksi terputus).',
        };
    }
}
function extractZipArchive(zipPath, destDir) {
    return new Promise((resolve, reject) => {
        if (process.platform === 'win32') {
            (0, child_process_1.execFile)('powershell.exe', [
                '-NoProfile',
                '-NonInteractive',
                '-Command',
                `Expand-Archive -LiteralPath '${zipPath.replace(/'/g, "''")}' -DestinationPath '${destDir.replace(/'/g, "''")}' -Force`,
            ], (err) => (err ? reject(err) : resolve()));
        }
        else {
            (0, child_process_1.execFile)('unzip', ['-o', zipPath, '-d', destDir], (err) => (err ? reject(err) : resolve()));
        }
    });
}
async function downloadAndApplyOtaUpdate(manifest) {
    if (!electron_1.app.isPackaged) {
        return {
            success: false,
            message: 'Auto-update hanya dapat dijalankan pada aplikasi terinstal (production build), bukan mode development.',
        };
    }
    const appRoot = electron_1.app.getAppPath();
    if (appRoot.toLowerCase().endsWith('.asar')) {
        return {
            success: false,
            message: 'Instalasi lama masih menggunakan paket .asar terkunci. Silakan install ulang sekali menggunakan installer terbaru (asar: false) agar update otomatis aktif.',
        };
    }
    const tempDir = fs_1.default.mkdtempSync(path_1.default.join(os_1.default.tmpdir(), 'pcs-erp-ota-'));
    const zipPath = path_1.default.join(tempDir, 'app-bundle.zip');
    const extractDir = path_1.default.join(tempDir, 'extracted');
    try {
        const res = await fetch(`${manifest.bundleUrl}?t=${Date.now()}`, { cache: 'no-store' });
        if (!res.ok) {
            throw new Error(`Gagal mengunduh paket update (HTTP ${res.status})`);
        }
        const arrayBuffer = await res.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        fs_1.default.writeFileSync(zipPath, buffer);
        const actualHash = crypto_1.default.createHash('sha256').update(buffer).digest('hex');
        if (manifest.sha256 && actualHash.toLowerCase() !== manifest.sha256.toLowerCase()) {
            throw new Error('Verifikasi keamanan file (SHA-256) gagal. File korup atau tidak cocok.');
        }
        fs_1.default.mkdirSync(extractDir, { recursive: true });
        await extractZipArchive(zipPath, extractDir);
        const newDist = path_1.default.join(extractDir, 'dist');
        const newDistElectron = path_1.default.join(extractDir, 'dist-electron');
        const newPkg = path_1.default.join(extractDir, 'package.json');
        if (!fs_1.default.existsSync(newDist) || !fs_1.default.existsSync(newDistElectron)) {
            throw new Error('Struktur paket update tidak valid (folder dist / dist-electron tidak ditemukan).');
        }
        const targetDist = path_1.default.join(appRoot, 'dist');
        const targetDistElectron = path_1.default.join(appRoot, 'dist-electron');
        const targetPkg = path_1.default.join(appRoot, 'package.json');
        const bakDist = path_1.default.join(tempDir, 'dist.bak');
        const bakDistElectron = path_1.default.join(tempDir, 'dist-electron.bak');
        if (fs_1.default.existsSync(targetDist))
            fs_1.default.cpSync(targetDist, bakDist, { recursive: true });
        if (fs_1.default.existsSync(targetDistElectron))
            fs_1.default.cpSync(targetDistElectron, bakDistElectron, { recursive: true });
        try {
            fs_1.default.rmSync(targetDist, { recursive: true, force: true });
            fs_1.default.rmSync(targetDistElectron, { recursive: true, force: true });
            fs_1.default.cpSync(newDist, targetDist, { recursive: true });
            fs_1.default.cpSync(newDistElectron, targetDistElectron, { recursive: true });
            if (fs_1.default.existsSync(newPkg)) {
                fs_1.default.copyFileSync(newPkg, targetPkg);
            }
        }
        catch (swapErr) {
            if (fs_1.default.existsSync(bakDist)) {
                fs_1.default.rmSync(targetDist, { recursive: true, force: true });
                fs_1.default.cpSync(bakDist, targetDist, { recursive: true });
            }
            if (fs_1.default.existsSync(bakDistElectron)) {
                fs_1.default.rmSync(targetDistElectron, { recursive: true, force: true });
                fs_1.default.cpSync(bakDistElectron, targetDistElectron, { recursive: true });
            }
            throw swapErr;
        }
        try {
            fs_1.default.rmSync(tempDir, { recursive: true, force: true });
        }
        catch {
            // ignore temp cleanup error
        }
        setTimeout(() => {
            electron_1.app.relaunch();
            electron_1.app.exit(0);
        }, 700);
        return {
            success: true,
            message: `Berhasil memperbarui ke v${manifest.version}. Aplikasi akan dimulai ulang...`,
        };
    }
    catch (err) {
        try {
            fs_1.default.rmSync(tempDir, { recursive: true, force: true });
        }
        catch {
            // ignore
        }
        return {
            success: false,
            message: err?.message || 'Terjadi kesalahan saat memperbarui aplikasi.',
        };
    }
}
