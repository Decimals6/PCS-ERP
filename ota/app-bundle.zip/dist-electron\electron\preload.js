"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const api = {
    // Master Barang
    listBarang: () => electron_1.ipcRenderer.invoke('barang:list'),
    createBarang: (data) => electron_1.ipcRenderer.invoke('barang:create', data),
    updateBarang: (id, data) => electron_1.ipcRenderer.invoke('barang:update', id, data),
    deleteBarang: (id) => electron_1.ipcRenderer.invoke('barang:delete', id),
    // Master Customer
    listCustomer: () => electron_1.ipcRenderer.invoke('customer:list'),
    createCustomer: (data) => electron_1.ipcRenderer.invoke('customer:create', data),
    updateCustomer: (id, data) => electron_1.ipcRenderer.invoke('customer:update', id, data),
    deleteCustomer: (id) => electron_1.ipcRenderer.invoke('customer:delete', id),
    // Master Supplier
    listSupplier: () => electron_1.ipcRenderer.invoke('supplier:list'),
    createSupplier: (data) => electron_1.ipcRenderer.invoke('supplier:create', data),
    updateSupplier: (id, data) => electron_1.ipcRenderer.invoke('supplier:update', id, data),
    deleteSupplier: (id) => electron_1.ipcRenderer.invoke('supplier:delete', id),
    // Bulk Import Master
    bulkImportMaster: (entity, rows) => electron_1.ipcRenderer.invoke('master:bulkImport', entity, rows),
    // Orders (PO / SO)
    listOrders: (type) => electron_1.ipcRenderer.invoke('order:list', type),
    getOrderById: (id) => electron_1.ipcRenderer.invoke('order:getById', id),
    getOrderByNo: (no) => electron_1.ipcRenderer.invoke('order:getByNo', no),
    createOrder: (data) => electron_1.ipcRenderer.invoke('order:create', data),
    updateOrder: (id, data) => electron_1.ipcRenderer.invoke('order:update', id, data),
    deleteOrder: (id) => electron_1.ipcRenderer.invoke('order:delete', id),
    // Delivery Notes (Surat Jalan)
    listDeliveryNotes: (type) => electron_1.ipcRenderer.invoke('dn:list', type),
    getDeliveryNoteById: (id) => electron_1.ipcRenderer.invoke('dn:getById', id),
    getDeliveryNoteForInvoice: (no) => electron_1.ipcRenderer.invoke('dn:getForInvoice', no),
    createDeliveryNote: (data) => electron_1.ipcRenderer.invoke('dn:create', data),
    updateDeliveryNote: (id, data) => electron_1.ipcRenderer.invoke('dn:update', id, data),
    deleteDeliveryNote: (id) => electron_1.ipcRenderer.invoke('dn:delete', id),
    // Mutasi Barang
    listMutasiBarang: (barangId) => electron_1.ipcRenderer.invoke('mutasi:list', barangId),
    createManualMutasi: (data) => electron_1.ipcRenderer.invoke('mutasi:createManual', data),
    updateManualMutasi: (id, data) => electron_1.ipcRenderer.invoke('mutasi:updateManual', id, data),
    deleteManualMutasi: (id) => electron_1.ipcRenderer.invoke('mutasi:deleteManual', id),
    // Samples
    listSamples: () => electron_1.ipcRenderer.invoke('sample:list'),
    getSampleById: (id) => electron_1.ipcRenderer.invoke('sample:getById', id),
    createSample: (data) => electron_1.ipcRenderer.invoke('sample:create', data),
    updateSample: (id, data) => electron_1.ipcRenderer.invoke('sample:update', id, data),
    deleteSample: (id) => electron_1.ipcRenderer.invoke('sample:delete', id),
    // Invoices
    listInvoices: (type) => electron_1.ipcRenderer.invoke('invoice:list', type),
    getInvoiceById: (id) => electron_1.ipcRenderer.invoke('invoice:getById', id),
    listUnpaidInvoicesByPartner: (type, partnerId) => electron_1.ipcRenderer.invoke('invoice:listUnpaidByPartner', type, partnerId),
    createInvoice: (data) => electron_1.ipcRenderer.invoke('invoice:create', data),
    updateInvoice: (id, data) => electron_1.ipcRenderer.invoke('invoice:update', id, data),
    deleteInvoice: (id) => electron_1.ipcRenderer.invoke('invoice:delete', id),
    // Payments
    listPayments: (type) => electron_1.ipcRenderer.invoke('payment:list', type),
    getPaymentById: (id) => electron_1.ipcRenderer.invoke('payment:getById', id),
    createPayment: (data) => electron_1.ipcRenderer.invoke('payment:create', data),
    updatePayment: (id, data) => electron_1.ipcRenderer.invoke('payment:update', id, data),
    deletePayment: (id) => electron_1.ipcRenderer.invoke('payment:delete', id),
    // Transfer JSON Antardivisi
    exportTransferJson: (docKind, id) => electron_1.ipcRenderer.invoke('transfer:exportJson', docKind, id),
    importTransferJson: () => electron_1.ipcRenderer.invoke('transfer:importJson'),
    // PDF & Templates & Settings & Backup
    buildDocumentHtml: (docType, docId) => electron_1.ipcRenderer.invoke('pdf:previewHtml', docType, docId),
    exportDocumentToPdf: (docType, docId) => electron_1.ipcRenderer.invoke('pdf:export', docType, docId),
    printDocumentDirect: (docType, docId) => electron_1.ipcRenderer.invoke('pdf:printDirect', docType, docId),
    listPdfTemplates: () => electron_1.ipcRenderer.invoke('template:list'),
    updatePdfTemplate: (docType, htmlContent, cssContent) => electron_1.ipcRenderer.invoke('template:update', docType, htmlContent, cssContent),
    resetPdfTemplate: (docType) => electron_1.ipcRenderer.invoke('template:reset', docType),
    getAppSettings: () => electron_1.ipcRenderer.invoke('settings:get'),
    updateAppSettings: (settings) => electron_1.ipcRenderer.invoke('settings:update', settings),
    backupDatabase: () => electron_1.ipcRenderer.invoke('db:backup'),
    restoreDatabase: () => electron_1.ipcRenderer.invoke('db:restore'),
    getDbPath: () => electron_1.ipcRenderer.invoke('db:path'),
    previewHumanBackupCounts: (startDate, endDate) => electron_1.ipcRenderer.invoke('backup:previewCounts', startDate, endDate),
    exportHumanBackup: (req) => electron_1.ipcRenderer.invoke('backup:exportHuman', req),
    // OTA Auto-Update
    getCurrentAppVersion: () => electron_1.ipcRenderer.invoke('updater:version'),
    checkForOtaUpdate: () => electron_1.ipcRenderer.invoke('updater:check'),
    applyOtaUpdate: (manifest) => electron_1.ipcRenderer.invoke('updater:apply', manifest),
};
electron_1.contextBridge.exposeInMainWorld('api', api);
