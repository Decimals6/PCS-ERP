"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.listBarang = listBarang;
exports.createBarang = createBarang;
exports.updateBarang = updateBarang;
exports.deleteBarang = deleteBarang;
exports.listCustomer = listCustomer;
exports.createCustomer = createCustomer;
exports.updateCustomer = updateCustomer;
exports.deleteCustomer = deleteCustomer;
exports.listSupplier = listSupplier;
exports.createSupplier = createSupplier;
exports.updateSupplier = updateSupplier;
exports.deleteSupplier = deleteSupplier;
exports.bulkImportMaster = bulkImportMaster;
const database_1 = require("../db/database");
// ==================== BARANG ====================
function listBarang() {
    return (0, database_1.queryAll)(`
    SELECT b.*, s.nama AS supplier_nama
    FROM barang b
    LEFT JOIN supplier s ON b.supplier_id = s.id
    ORDER BY b.id DESC
  `);
}
function createBarang(data) {
    const res = (0, database_1.execute)(`INSERT INTO barang (kode, part_number, supplier_id, nama, satuan, keterangan, stock)
     VALUES (?, ?, ?, ?, ?, ?, ?)`, [
        data.kode || '',
        data.part_number || '',
        data.supplier_id ?? null,
        data.nama || '',
        data.satuan || 'PCS',
        data.keterangan || '',
        Number(data.stock || 0),
    ]);
    return (0, database_1.queryOne)('SELECT * FROM barang WHERE id = ?', [res.lastInsertRowid]);
}
function updateBarang(id, data) {
    (0, database_1.execute)(`UPDATE barang
     SET kode = ?, part_number = ?, supplier_id = ?, nama = ?, satuan = ?, keterangan = ?, stock = ?
     WHERE id = ?`, [
        data.kode || '',
        data.part_number || '',
        data.supplier_id ?? null,
        data.nama || '',
        data.satuan || 'PCS',
        data.keterangan || '',
        Number(data.stock || 0),
        id,
    ]);
    return (0, database_1.queryOne)('SELECT * FROM barang WHERE id = ?', [id]);
}
function deleteBarang(id) {
    (0, database_1.execute)('DELETE FROM barang WHERE id = ?', [id]);
}
// ==================== CUSTOMER ====================
function listCustomer() {
    return (0, database_1.queryAll)('SELECT * FROM customer ORDER BY id DESC');
}
function createCustomer(data) {
    const res = (0, database_1.execute)(`INSERT INTO customer (kode, nama, alamat, email, telepon, UP)
     VALUES (?, ?, ?, ?, ?, ?)`, [
        data.kode || '',
        data.nama || '',
        data.alamat || '',
        data.email || '',
        data.telepon || '',
        data.UP || '',
    ]);
    return (0, database_1.queryOne)('SELECT * FROM customer WHERE id = ?', [res.lastInsertRowid]);
}
function updateCustomer(id, data) {
    (0, database_1.execute)(`UPDATE customer
     SET kode = ?, nama = ?, alamat = ?, email = ?, telepon = ?, UP = ?
     WHERE id = ?`, [
        data.kode || '',
        data.nama || '',
        data.alamat || '',
        data.email || '',
        data.telepon || '',
        data.UP || '',
        id,
    ]);
    return (0, database_1.queryOne)('SELECT * FROM customer WHERE id = ?', [id]);
}
function deleteCustomer(id) {
    (0, database_1.execute)('DELETE FROM customer WHERE id = ?', [id]);
}
// ==================== SUPPLIER ====================
function listSupplier() {
    return (0, database_1.queryAll)('SELECT * FROM supplier ORDER BY id DESC');
}
function createSupplier(data) {
    const res = (0, database_1.execute)(`INSERT INTO supplier (kode, nama, alamat, email, telepon, UP)
     VALUES (?, ?, ?, ?, ?, ?)`, [
        data.kode || '',
        data.nama || '',
        data.alamat || '',
        data.email || '',
        data.telepon || '',
        data.UP || '',
    ]);
    return (0, database_1.queryOne)('SELECT * FROM supplier WHERE id = ?', [res.lastInsertRowid]);
}
function updateSupplier(id, data) {
    (0, database_1.execute)(`UPDATE supplier
     SET kode = ?, nama = ?, alamat = ?, email = ?, telepon = ?, UP = ?
     WHERE id = ?`, [
        data.kode || '',
        data.nama || '',
        data.alamat || '',
        data.email || '',
        data.telepon || '',
        data.UP || '',
        id,
    ]);
    return (0, database_1.queryOne)('SELECT * FROM supplier WHERE id = ?', [id]);
}
function deleteSupplier(id) {
    (0, database_1.execute)('DELETE FROM supplier WHERE id = ?', [id]);
}
// ==================== BULK IMPORT (CSV / JSON) ====================
function bulkImportMaster(entity, rows) {
    let inserted = 0;
    let updated = 0;
    (0, database_1.runTransaction)(() => {
        for (const row of rows) {
            const kode = String(row.kode ?? row.code ?? '').trim();
            const nama = String(row.nama ?? row.name ?? '').trim();
            if (!nama && !kode)
                continue;
            if (entity === 'barang') {
                const partNumber = String(row.part_number ?? row.partNumber ?? '').trim();
                const satuan = String(row.satuan ?? row.unit ?? 'PCS').trim() || 'PCS';
                const keterangan = String(row.keterangan ?? row.notes ?? '').trim();
                const stock = Number(row.stock ?? row.stok ?? 0) || 0;
                const supplierId = row.supplier_id ? Number(row.supplier_id) : null;
                const existing = kode
                    ? (0, database_1.queryOne)('SELECT id FROM barang WHERE kode = ?', [kode])
                    : null;
                if (existing) {
                    (0, database_1.execute)(`UPDATE barang SET part_number = ?, supplier_id = ?, nama = ?, satuan = ?, keterangan = ?, stock = ? WHERE id = ?`, [partNumber, supplierId, nama, satuan, keterangan, stock, existing.id], false);
                    updated++;
                }
                else {
                    (0, database_1.execute)(`INSERT INTO barang (kode, part_number, supplier_id, nama, satuan, keterangan, stock) VALUES (?, ?, ?, ?, ?, ?, ?)`, [kode, partNumber, supplierId, nama, satuan, keterangan, stock], false);
                    inserted++;
                }
            }
            else if (entity === 'customer') {
                const alamat = String(row.alamat ?? row.address ?? '').trim();
                const email = String(row.email ?? '').trim();
                const telepon = String(row.telepon ?? row.phone ?? '').trim();
                const up = String(row.UP ?? row.up ?? '').trim();
                const existing = kode
                    ? (0, database_1.queryOne)('SELECT id FROM customer WHERE kode = ?', [kode])
                    : null;
                if (existing) {
                    (0, database_1.execute)(`UPDATE customer SET nama = ?, alamat = ?, email = ?, telepon = ?, UP = ? WHERE id = ?`, [nama, alamat, email, telepon, up, existing.id], false);
                    updated++;
                }
                else {
                    (0, database_1.execute)(`INSERT INTO customer (kode, nama, alamat, email, telepon, UP) VALUES (?, ?, ?, ?, ?, ?)`, [kode, nama, alamat, email, telepon, up], false);
                    inserted++;
                }
            }
            else if (entity === 'supplier') {
                const alamat = String(row.alamat ?? row.address ?? '').trim();
                const email = String(row.email ?? '').trim();
                const telepon = String(row.telepon ?? row.phone ?? '').trim();
                const up = String(row.UP ?? row.up ?? '').trim();
                const existing = kode
                    ? (0, database_1.queryOne)('SELECT id FROM supplier WHERE kode = ?', [kode])
                    : null;
                if (existing) {
                    (0, database_1.execute)(`UPDATE supplier SET nama = ?, alamat = ?, email = ?, telepon = ?, UP = ? WHERE id = ?`, [nama, alamat, email, telepon, up, existing.id], false);
                    updated++;
                }
                else {
                    (0, database_1.execute)(`INSERT INTO supplier (kode, nama, alamat, email, telepon, UP) VALUES (?, ?, ?, ?, ?, ?)`, [kode, nama, alamat, email, telepon, up], false);
                    inserted++;
                }
            }
        }
    });
    return { inserted, updated };
}
