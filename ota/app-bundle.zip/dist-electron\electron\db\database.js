"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDbPath = getDbPath;
exports.initDatabase = initDatabase;
exports.getDb = getDb;
exports.saveDatabase = saveDatabase;
exports.queryAll = queryAll;
exports.queryOne = queryOne;
exports.execute = execute;
exports.runTransaction = runTransaction;
exports.reloadDatabaseFromFile = reloadDatabaseFromFile;
const sql_js_1 = __importDefault(require("sql.js"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const electron_1 = require("electron");
let dbInstance = null;
let dbFilePath = '';
function resolveWasmPath() {
    if (electron_1.app.isPackaged) {
        return path_1.default.join(process.resourcesPath, 'sql-wasm.wasm');
    }
    return require.resolve('sql.js/dist/sql-wasm.wasm');
}
function getDbPath() {
    if (!dbFilePath) {
        const userDataDir = electron_1.app.getPath('userData');
        if (!fs_1.default.existsSync(userDataDir)) {
            fs_1.default.mkdirSync(userDataDir, { recursive: true });
        }
        dbFilePath = path_1.default.join(userDataDir, 'erp_offline.db');
    }
    return dbFilePath;
}
async function initDatabase() {
    if (dbInstance)
        return dbInstance;
    const wasmPath = resolveWasmPath();
    const rawWasm = fs_1.default.readFileSync(wasmPath);
    const wasmBinary = rawWasm.buffer.slice(rawWasm.byteOffset, rawWasm.byteOffset + rawWasm.byteLength);
    const SQL = await (0, sql_js_1.default)({
        wasmBinary,
        useOldExtensionFunctions: false,
    });
    const filePath = getDbPath();
    if (fs_1.default.existsSync(filePath)) {
        const fileBuffer = fs_1.default.readFileSync(filePath);
        dbInstance = new SQL.Database(new Uint8Array(fileBuffer));
    }
    else {
        dbInstance = new SQL.Database();
    }
    saveDatabase();
    return dbInstance;
}
function getDb() {
    if (!dbInstance) {
        throw new Error('Database belum diinisialisasi.');
    }
    return dbInstance;
}
function saveDatabase() {
    if (!dbInstance)
        return;
    const data = dbInstance.export();
    const buffer = Buffer.from(data);
    const filePath = getDbPath();
    const tempPath = `${filePath}.tmp`;
    fs_1.default.writeFileSync(tempPath, buffer);
    fs_1.default.renameSync(tempPath, filePath);
}
function queryAll(sql, params = []) {
    const db = getDb();
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const rows = [];
    while (stmt.step()) {
        rows.push(stmt.getAsObject());
    }
    stmt.free();
    return rows;
}
function queryOne(sql, params = []) {
    const rows = queryAll(sql, params);
    return rows.length > 0 ? rows[0] : null;
}
function execute(sql, params = [], autoSave = true) {
    const db = getDb();
    db.run(sql, params);
    const idRes = queryOne('SELECT last_insert_rowid() AS id');
    const changes = db.getRowsModified();
    if (autoSave) {
        saveDatabase();
    }
    return {
        lastInsertRowid: idRes ? Number(idRes.id) : 0,
        changes,
    };
}
function runTransaction(fn) {
    const db = getDb();
    db.run('BEGIN TRANSACTION');
    try {
        const result = fn();
        db.run('COMMIT');
        saveDatabase();
        return result;
    }
    catch (err) {
        try {
            db.run('ROLLBACK');
        }
        catch {
            // ignore rollback error
        }
        throw err;
    }
}
async function reloadDatabaseFromFile(sourcePath) {
    const wasmPath = resolveWasmPath();
    const rawWasm = fs_1.default.readFileSync(wasmPath);
    const wasmBinary = rawWasm.buffer.slice(rawWasm.byteOffset, rawWasm.byteOffset + rawWasm.byteLength);
    const SQL = await (0, sql_js_1.default)({ wasmBinary, useOldExtensionFunctions: false });
    const fileBuffer = fs_1.default.readFileSync(sourcePath);
    if (dbInstance) {
        dbInstance.close();
    }
    dbInstance = new SQL.Database(new Uint8Array(fileBuffer));
    saveDatabase();
}
