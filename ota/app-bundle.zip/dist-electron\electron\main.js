"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const database_1 = require("./db/database");
const migrations_1 = require("./db/migrations");
const masterService = __importStar(require("./services/masterService"));
const orderDeliveryService = __importStar(require("./services/orderDeliveryService"));
const invoicePaymentService = __importStar(require("./services/invoicePaymentService"));
const pdfBackupService = __importStar(require("./services/pdfBackupService"));
const exportBackupService = __importStar(require("./services/exportBackupService"));
const updaterService = __importStar(require("./services/updaterService"));
let mainWindow = null;
function createMainWindow() {
    mainWindow = new electron_1.BrowserWindow({
        width: 1340,
        height: 840,
        minWidth: 1080,
        minHeight: 680,
        title: 'PCS-ERP - Sistem Administrasi & Dokumen Offline',
        webPreferences: {
            preload: path_1.default.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: false, // <-- Tambahkan ini!
        },
    });
    if (!electron_1.app.isPackaged) {
        mainWindow.loadURL(process.env.VITE_DEV_SERVER_URL || 'http://localhost:5173');
    }
    else {
        mainWindow.loadFile(path_1.default.join(__dirname, '../../dist/index.html'));
    }
}
function registerIpcHandlers() {
    // Master Barang
    electron_1.ipcMain.handle('barang:list', () => masterService.listBarang());
    electron_1.ipcMain.handle('barang:create', (_e, data) => masterService.createBarang(data));
    electron_1.ipcMain.handle('barang:update', (_e, id, data) => masterService.updateBarang(id, data));
    electron_1.ipcMain.handle('barang:delete', (_e, id) => masterService.deleteBarang(id));
    // Master Customer
    electron_1.ipcMain.handle('customer:list', () => masterService.listCustomer());
    electron_1.ipcMain.handle('customer:create', (_e, data) => masterService.createCustomer(data));
    electron_1.ipcMain.handle('customer:update', (_e, id, data) => masterService.updateCustomer(id, data));
    electron_1.ipcMain.handle('customer:delete', (_e, id) => masterService.deleteCustomer(id));
    // Master Supplier
    electron_1.ipcMain.handle('supplier:list', () => masterService.listSupplier());
    electron_1.ipcMain.handle('supplier:create', (_e, data) => masterService.createSupplier(data));
    electron_1.ipcMain.handle('supplier:update', (_e, id, data) => masterService.updateSupplier(id, data));
    electron_1.ipcMain.handle('supplier:delete', (_e, id) => masterService.deleteSupplier(id));
    // Bulk Import
    electron_1.ipcMain.handle('master:bulkImport', (_e, entity, rows) => masterService.bulkImportMaster(entity, rows));
    // Orders
    electron_1.ipcMain.handle('order:list', (_e, type) => orderDeliveryService.listOrders(type));
    electron_1.ipcMain.handle('order:getById', (_e, id) => orderDeliveryService.getOrderById(id));
    electron_1.ipcMain.handle('order:getByNo', (_e, no) => orderDeliveryService.getOrderByNo(no));
    electron_1.ipcMain.handle('order:create', (_e, data) => orderDeliveryService.createOrder(data));
    electron_1.ipcMain.handle('order:update', (_e, id, data) => orderDeliveryService.updateOrder(id, data));
    electron_1.ipcMain.handle('order:delete', (_e, id) => orderDeliveryService.deleteOrder(id));
    // Delivery Notes
    electron_1.ipcMain.handle('dn:list', (_e, type) => orderDeliveryService.listDeliveryNotes(type));
    electron_1.ipcMain.handle('dn:getById', (_e, id) => orderDeliveryService.getDeliveryNoteById(id));
    electron_1.ipcMain.handle('dn:getForInvoice', (_e, no) => orderDeliveryService.getDeliveryNoteForInvoice(no));
    electron_1.ipcMain.handle('dn:create', (_e, data) => orderDeliveryService.createDeliveryNote(data));
    electron_1.ipcMain.handle('dn:update', (_e, id, data) => orderDeliveryService.updateDeliveryNote(id, data));
    electron_1.ipcMain.handle('dn:delete', (_e, id) => orderDeliveryService.deleteDeliveryNote(id));
    // Mutasi Barang
    electron_1.ipcMain.handle('mutasi:list', (_e, barangId) => orderDeliveryService.listMutasiBarang(barangId));
    electron_1.ipcMain.handle('mutasi:createManual', (_e, data) => orderDeliveryService.createManualMutasi(data));
    electron_1.ipcMain.handle('mutasi:updateManual', (_e, id, data) => orderDeliveryService.updateManualMutasi(id, data));
    electron_1.ipcMain.handle('mutasi:deleteManual', (_e, id) => orderDeliveryService.deleteManualMutasi(id));
    electron_1.ipcMain.handle('mutasi:rebuildFromDocs', (_e, options) => orderDeliveryService.rebuildMutasiAndStockFromDocuments(options));
    // Samples
    electron_1.ipcMain.handle('sample:list', () => orderDeliveryService.listSamples());
    electron_1.ipcMain.handle('sample:getById', (_e, id) => orderDeliveryService.getSampleById(id));
    electron_1.ipcMain.handle('sample:create', (_e, data) => orderDeliveryService.createSample(data));
    electron_1.ipcMain.handle('sample:update', (_e, id, data) => orderDeliveryService.updateSample(id, data));
    electron_1.ipcMain.handle('sample:delete', (_e, id) => orderDeliveryService.deleteSample(id));
    // Invoices
    electron_1.ipcMain.handle('invoice:list', (_e, type) => invoicePaymentService.listInvoices(type));
    electron_1.ipcMain.handle('invoice:getById', (_e, id) => invoicePaymentService.getInvoiceById(id));
    electron_1.ipcMain.handle('invoice:listUnpaidByPartner', (_e, type, partnerId) => invoicePaymentService.listUnpaidInvoicesByPartner(type, partnerId));
    electron_1.ipcMain.handle('invoice:create', (_e, data) => invoicePaymentService.createInvoice(data));
    electron_1.ipcMain.handle('invoice:update', (_e, id, data) => invoicePaymentService.updateInvoice(id, data));
    electron_1.ipcMain.handle('invoice:delete', (_e, id) => invoicePaymentService.deleteInvoice(id));
    // Payments
    electron_1.ipcMain.handle('payment:list', (_e, type) => invoicePaymentService.listPayments(type));
    electron_1.ipcMain.handle('payment:getById', (_e, id) => invoicePaymentService.getPaymentById(id));
    electron_1.ipcMain.handle('payment:create', (_e, data) => invoicePaymentService.createPayment(data));
    electron_1.ipcMain.handle('payment:update', (_e, id, data) => invoicePaymentService.updatePayment(id, data));
    electron_1.ipcMain.handle('payment:delete', (_e, id) => invoicePaymentService.deletePayment(id));
    // Transfer JSON Antardivisi
    electron_1.ipcMain.handle('transfer:exportJson', async (_e, docKind, id) => {
        const payload = orderDeliveryService.buildTransferPayload(docKind, id);
        const safeNo = String(payload.header.no || id).replace(/[^a-zA-Z0-9-_]/g, '_');
        const { canceled, filePath } = await electron_1.dialog.showSaveDialog({
            title: `Export Dokumen Transfer (${docKind})`,
            defaultPath: `TRANSFER_${docKind}_${safeNo}.json`,
            filters: [{ name: 'JSON Transfer File', extensions: ['json'] }],
        });
        if (canceled || !filePath)
            return { saved: false };
        fs_1.default.writeFileSync(filePath, JSON.stringify(payload, null, 2), 'utf-8');
        return { saved: true, filePath };
    });
    electron_1.ipcMain.handle('transfer:importJson', async () => {
        const { canceled, filePaths } = await electron_1.dialog.showOpenDialog({
            title: 'Pilih File Dokumen Transfer (.json)',
            filters: [{ name: 'JSON Transfer File', extensions: ['json'] }],
            properties: ['openFile'],
        });
        if (canceled || filePaths.length === 0)
            return null;
        const raw = fs_1.default.readFileSync(filePaths[0], 'utf-8');
        const parsed = JSON.parse(raw);
        if (!parsed.doc_kind || !Array.isArray(parsed.items)) {
            throw new Error('Format file transfer JSON tidak valid.');
        }
        return parsed;
    });
    // PDF, Templates, Settings & Backup
    electron_1.ipcMain.handle('pdf:previewHtml', (_e, docType, docId) => pdfBackupService.buildDocumentHtml(docType, docId));
    electron_1.ipcMain.handle('pdf:export', (_e, docType, docId) => pdfBackupService.exportDocumentToPdf(docType, docId));
    electron_1.ipcMain.handle('pdf:printDirect', (_e, docType, docId) => pdfBackupService.printDocumentDirect(docType, docId));
    electron_1.ipcMain.handle('template:list', () => pdfBackupService.listPdfTemplates());
    electron_1.ipcMain.handle('template:update', (_e, docType, html, css) => pdfBackupService.updatePdfTemplate(docType, html, css));
    electron_1.ipcMain.handle('template:reset', (_e, docType) => pdfBackupService.resetPdfTemplate(docType));
    electron_1.ipcMain.handle('settings:get', () => pdfBackupService.getAppSettings());
    electron_1.ipcMain.handle('settings:update', (_e, settings) => pdfBackupService.updateAppSettings(settings));
    electron_1.ipcMain.handle('db:backup', () => pdfBackupService.backupDatabase());
    electron_1.ipcMain.handle('db:restore', () => pdfBackupService.restoreDatabase());
    electron_1.ipcMain.handle('db:path', () => (0, database_1.getDbPath)());
    electron_1.ipcMain.handle('db:selectCustomBackupFolder', () => pdfBackupService.selectCustomBackupFolder());
    electron_1.ipcMain.handle('db:openLocation', (_e, targetPath) => pdfBackupService.openBackupLocation(targetPath));
    // Human-Readable Excel / CSV Backup
    electron_1.ipcMain.handle('backup:previewCounts', (_e, startDate, endDate) => exportBackupService.previewHumanBackupCounts(startDate, endDate));
    electron_1.ipcMain.handle('backup:exportHuman', (_e, req) => exportBackupService.exportHumanBackup(req));
    // OTA Auto-Update
    electron_1.ipcMain.handle('updater:version', () => updaterService.getCurrentAppVersion());
    electron_1.ipcMain.handle('updater:check', () => updaterService.checkForOtaUpdate());
    electron_1.ipcMain.handle('updater:apply', (_e, manifest) => updaterService.downloadAndApplyOtaUpdate(manifest));
}
electron_1.app.whenReady().then(async () => {
    await (0, database_1.initDatabase)();
    (0, migrations_1.runMigrations)();
    registerIpcHandlers();
    createMainWindow();
    electron_1.app.on('activate', () => {
        if (electron_1.BrowserWindow.getAllWindows().length === 0) {
            createMainWindow();
        }
    });
});
electron_1.app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        electron_1.app.quit();
    }
});
